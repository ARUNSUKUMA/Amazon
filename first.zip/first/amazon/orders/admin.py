from django.contrib import admin

# Register your models here.
from orders.models import data1
admin.site.register(data1)