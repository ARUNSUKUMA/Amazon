from django.contrib import admin

# Register your models here.
from shipping.models import data2
admin.site.register(data2)